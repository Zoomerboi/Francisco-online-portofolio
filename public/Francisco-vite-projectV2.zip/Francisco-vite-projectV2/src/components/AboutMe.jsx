import React from 'react';

function AboutMe() {
  return (
    <main>
      <br />
      <h2> ABOUT ME </h2>
      <br />
      
      <div className="text-center" style={{ textAlign: 'center' }}>
        <a href="https://www.facebook.com/ethanedgar.francisco">
          <img 
            src="/ETHAN.jpg"
            height="200" 
            alt="Ethan Pogi" 
            style={{ border: '1px solid black', padding: '5px', borderRadius: '6px' }} 
          />
        </a>
        <br />
        <section>
          <p style={{ fontWeight: 'bold' }}> Ethan Francisco </p>
        </section>
      </div>

      {/* Badges */}
      <div style={{ textAlign: 'center', marginBottom: '20px' }}>
        <span className="badge rounded-pill bg-primary me-1">CSS</span>
        <span className="badge rounded-pill bg-secondary me-1">HTML</span>
        <span className="badge rounded-pill bg-success me-1">Linux</span>
        <span className="badge rounded-pill bg-danger me-1">Python</span>
        <span className="badge rounded-pill bg-warning text-dark">Renpy</span>
      </div>

      <div className="accordion" id="accordionPanelsStayOpenExample">
        
        <div className="accordion-item">
          <h2 className="accordion-header" id="panelsStayOpen-headingOne">
            <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
              Who Am I?
            </button>
          </h2>
          <div id="panelsStayOpen-collapseOne" className="accordion-collapse collapse show" aria-labelledby="panelsStayOpen-headingOne">
            <div className="accordion-body">
              I am Ethan I like Videogames and writing Novels, I am Undergraduate at Asia Pacific College taking Computer Science with a specialization in Cyber Security and Forensics.
            </div>
          </div>
        </div>
        
        <div className="accordion-item">
          <h2 className="accordion-header" id="panelsStayOpen-headingTwo">
            <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="false" aria-controls="panelsStayOpen-collapseTwo">
              Top 20 Videogames:
            </button>
          </h2>
          <div id="panelsStayOpen-collapseTwo" className="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
            <div className="accordion-body">
              <ul className="list-group list-group-flush">
                <li className="list-group-item">Ghost of Tsushima</li>
                <li className="list-group-item">Elden Ring</li>
                <li className="list-group-item">God of War</li>
                <li className="list-group-item">Bioshock</li>
                <li className="list-group-item">Fallout 4</li>
                <li className="list-group-item">Horizon Zero Dawn</li>
                <li className="list-group-item">Metro Exodus</li>
                <li className="list-group-item">Borderlands 3</li>
                <li className="list-group-item">Last Of Us</li>
                <li className="list-group-item">Red Dead Redemption 2</li>
                <li className="list-group-item">Far Cry 5</li>
                <li className="list-group-item">Watch Dogs 2</li>
                <li className="list-group-item">Middle Earth Shadow of War</li>
                <li className="list-group-item">Cyberpunk 2077</li>
                <li className="list-group-item">Days Gone</li>
                <li className="list-group-item">Risk of Rain 2</li>
                <li className="list-group-item">Resident Evil Village</li>
                <li className="list-group-item">Va-11 Hall-A</li>
                <li className="list-group-item">Armored Core 6</li>
                <li className="list-group-item">Until Then</li>
                <li className="list-group-item">Nier Automata</li>
                <li className="list-group-item">Dispatch</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="accordion-item">
          <h2 className="accordion-header" id="panelsStayOpen-headingThree">
            <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="false" aria-controls="panelsStayOpen-collapseThree">
              Top 20 Animes:
            </button>
          </h2>
          <div id="panelsStayOpen-collapseThree" className="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
            <div className="accordion-body">
              <ul className="list-group list-group-flush">
                <li className="list-group-item">Jujutsu Kaisen</li>
                <li className="list-group-item">Steins Gate</li>
                <li className="list-group-item">Overlord</li>
                <li className="list-group-item">Ancient Magus Bride</li>
                <li className="list-group-item">Vivy</li>
                <li className="list-group-item">Terror in Resonance</li>
                <li className="list-group-item">Cyberpunk Edgerunners</li>
                <li className="list-group-item">I want to eat your pancreas</li>
                <li className="list-group-item">After the rain</li>
                <li className="list-group-item">Chainsaw man</li>
                <li className="list-group-item">Kill la kill</li>
                <li className="list-group-item">Dororo</li>
                <li className="list-group-item">Highschool of the dead</li>
                <li className="list-group-item">Bungo Stray Dogs</li>
                <li className="list-group-item">Black Lagoon</li>
                <li className="list-group-item">Inuyashiki</li>
                <li className="list-group-item">Psycho pass</li>
                <li className="list-group-item">Hells Paradise</li>
                <li className="list-group-item">Durarara</li>
                <li className="list-group-item">Gate</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}

export default AboutMe;