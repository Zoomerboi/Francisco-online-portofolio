import React from 'react';

const footerStyle = {
  backgroundColor: 'rgb(112, 3, 3)',
  color: '#fff',
  textAlign: 'center',
  padding: '15px 5px',
  fontFamily: 'Verdana, sans-serif',
  fontSize: '1.0em', 
  opacity: 0.85,
};

function Footer() {
  return (
    <footer style={footerStyle}>
      <p>Hi Im Ethan and I love videogames</p>
    </footer>
  );
}

export default Footer;