import React from 'react';

function HomeContent() {
  return (
    <main>
      <h2 className="dispatch-title-h2">Dispatch is so peak T_T</h2>
      <br />
      <details style={{ float: 'right' }}>
        <summary>
          <i>Things to love about it.</i>
        </summary>
        <ol>
          <li><p> Every character is likeable. </p></li>
          <li><p> The animations is well done. </p></li>
          <li><p> The story is absolutely compelling. </p></li>
          <li><p> Superheroes are still cool. </p></li>
          <li><p> You can feel the emotional pull of the choices you make. </p></li>
        </ol>
      </details>

      <article>
        <p>What is <strong>Dispatch</strong> you say?</p>
        <p id="para1">
          Its a game that released a couple
          <br /> of weeks back that is story focused
        </p>
        <p>Can't tell much more don't wanna spoil you</p>
      </article>
      <aside>
        <p>
          {' '}
          what do you expect from a team of <u>telltale veterans.</u>{' '}
        </p>
      </aside>
      <br />
      <br />

      <div className="gallery">
        <div className="gallery-item">
          <a
            target="_blank"
            href="https://static0.thegamerimages.com/wordpress/wp-content/uploads/2025/06/dispatch-cutscene.jpg?w=1600&h=900&fit=crop"
          >
            <img
              src="https://static0.thegamerimages.com/wordpress/wp-content/uploads/2025/06/dispatch-cutscene.jpg?w=1600&h=900&fit=crop"
              alt="The team"
            />
          </a>
          <div className="desc">Team meeting</div>
        </div>

        <div className="gallery-item">
          <a
            target="_blank"
            href="https://assetsio.gnwcdn.com/dispatch.jpg?width=690&quality=85&format=jpg&dpr=3&auto=webp"
          >
            <img
              src="https://assetsio.gnwcdn.com/dispatch.jpg?width=690&quality=85&format=jpg&dpr=3&auto=webp"
              alt="Chase and Blonde blazer"
              title="Blonde Blazer and Chase"
            />
          </a>
          <div className="desc">Chase and Blonde Blazer</div>
        </div>

        <div className="gallery-item">
          <a
            target="_blank"
            href="https://static0.gamerantimages.com/wordpress/wp-content/uploads/wm/2025/10/dispatch-episode-2-walkthrough-1.jpg?q=49&fit=crop&w=825&dpr=2"
          >
            <img
              src="https://static0.gamerantimages.com/wordpress/wp-content/uploads/wm/2025/10/dispatch-episode-2-walkthrough-1.jpg?q=49&fit=crop&w=825&dpr=2"
              alt="waterboy scene"
            />
          </a>
          <div className="desc">Waterboy confiding in Robert</div>
        </div>
      </div>

      <nav style={{ fontSize: '100%' }}>
        <p>here are some of the other characters:</p>
        <a href="https://dispatch.fandom.com/wiki/Invisigal">Invisigal</a>
        <a href="https://dispatch.fandom.com/wiki/Blonde_Blazer">Blonde Blazer</a>
        <a href="https://dispatch.fandom.com/wiki/Robert_Robertson">Mecha Man</a>
      </nav>
      <br />
      <p>here are some other side characters:</p>

      <table>
        <thead>
          <tr>
            <th>Characters</th>
            <th>Powers</th>
            <th>Gender</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Flambae</td>
            <td>Pyrokinesis</td>
            <td>Male</td>
          </tr>
          <tr>
            <td>Golem</td>
            <td>Sentient Clay</td>
            <td>Male</td>
          </tr>
          <tr>
            <td>Coupe'</td>
            <td>Wings and Blades</td>
            <td>Female</td>
          </tr>
          <tr>
            <td>Prism</td>
            <td>Holograms</td>
            <td>Female</td>
          </tr>
          <tr>
            <td>Waterboy</td>
            <td>spits water</td>
            <td>Male</td>
          </tr>
        </tbody>
      </table>
      <br />

      <figure style={{ textAlign: 'center' }}>
        <div className="tooltip-custom">
          <span className="tooltip-text">MOIST CRITIKAL BTW</span>
          <a href="https://dispatch.fandom.com/wiki/Sonar">
            <img
              src="/sonar.png"
              height="200"
              alt="Sonar My Goat"
              style={{ border: '1px solid black', padding: '5px', borderRadius: '6px' }}
            />{' '}
          </a>
        </div>
        <figcaption style={{ fontSize: '120%' }}>
          {' '}
          I mean look at this dapper fella his name is <mark>Sonar</mark> btw.{' '}
        </figcaption>
      </figure>

      <section style={{ textAlign: 'center' }}>
        <div className="dropdown">
          <h1> About Adhoc </h1>
          <div className="dropdown-content">
            an independent game developer founded by an award winning creative team.
          </div>
        </div>
        <p>
          Adhoc are the developers behind Dispatch and fun fact is this is their debut game as a
          new company
        </p>
      </section>

      <p style={{ textAlign: 'center' }}>
        Release date and time for Dispatch is:{' '}
        <time className="release-time" dateTime="2025-10-22T12:00">
          October 22 at 12:00 AM
        </time>
        .
      </p>

      <div className="comments">
        <h3>Comments</h3>
        <div className="comment-box" />
      </div>
    </main>
  );
}

export default HomeContent;