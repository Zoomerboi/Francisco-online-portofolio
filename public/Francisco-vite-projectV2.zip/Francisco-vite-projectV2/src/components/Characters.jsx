import React, { useEffect } from 'react';

function Characters() {
useEffect(() => {
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    
    if (window.bootstrap) {
      [...tooltipTriggerList].forEach(tooltipTriggerEl => 
        new window.bootstrap.Tooltip(tooltipTriggerEl)
      );
    }
  }, []);

  return (
    <main>
      <br />
      <h2>CHARACTERS</h2>
      <br />
      
      {/* Container for the cards */}
      <div className="container">
        <div className="row">
          
          {/* Row 1 */}
          <div className="col-md-4 mb-4">
            <div className="card" data-bs-toggle="tooltip" data-bs-placement="top" title="You're cute">
              <img src="https://preview.redd.it/malevola-and-prism-v0-tjik0n6lja7e1.jpg?width=1080&crop=smart&auto=webp&s=d0858e00f626148e49bc3015b0b2ae306008de70" className="card-img-top" alt="malevola" />
              <div className="card-body">
                <p className="card-text">Malevola</p>
              </div>
            </div>
          </div>
          
          <div className="col-md-4 mb-4">
            <div className="card" data-bs-toggle="tooltip" data-bs-placement="top" title="You gotta drop and roll lad">
              <img src="https://ella.janitorai.com/bot-avatars/bYm9svk0zTZIaYVxPGGUq.webp?width=1200" className="card-img-top" alt="punchup" />
              <div className="card-body">
                <p className="card-text">Punch-Up</p>
              </div>
            </div>
          </div>
          
          <div className="col-md-4 mb-4">
            <div className="card" data-bs-toggle="tooltip" data-bs-placement="top" title="F**k I need this job">
              <img src="https://static1.personalitydatabase.net/2/pdb-images-prod/a05a3a11/profile_images/c2e3a17bf7a34f1eb79a61ce8303fa6f.png" className="card-img-top" alt="coupe" />
              <div className="card-body">
                <p className="card-text">Coupe'</p>
              </div>
            </div>
          </div>
          
          {/* Row 2 */}
          <div className="col-md-4 mb-4">
            <div className="card" data-bs-toggle="tooltip" data-bs-placement="top" title="I'm a b***h named Robert">
              <img src="https://images.genius.com/54d01d97df2671efd19710daebbad529.1000x1000x1.webp" className="card-img-top" alt="flambae" />
              <div className="card-body">
                <p className="card-text">Flambae</p>
              </div>
            </div>
          </div>
          
          <div className="col-md-4 mb-4">
            <div className="card" data-bs-toggle="tooltip" data-bs-placement="top" title="I'll sit on the floor">
              <img src="https://ella.janitorai.com/bot-avatars/8fxyGR5JvjzWoiPoxcwQL.webp?width=1200" className="card-img-top" alt="golem" />
              <div className="card-body">
                <p className="card-text">Golem</p>
              </div>
            </div>
          </div>
          
          <div className="col-md-4 mb-4">
            <div className="card" data-bs-toggle="tooltip" data-bs-placement="top" title="You gonna eat those twinks?">
              <img src="https://img.game8.co/4321377/c49876476ce02f6dbcb0b5647c75fa1d.jpeg/show" className="card-img-top" alt="sonar" />
              <div className="card-body">
                <p className="card-text">Sonar</p>
              </div>
            </div>
          </div>
          
          {/* Row 3 */}
          <div className="col-md-4 mb-4">
            <div className="card" data-bs-toggle="tooltip" data-bs-placement="top" title="I will make love to you now">
              <img src="https://preview.redd.it/is-it-just-me-or-does-phenomeman-act-just-like-a-viltrumite-v0-apf9ztka2lxf1.jpeg?width=640&crop=smart&auto=webp&s=b20b2667cfc313ef3f710a348d2a6bf3c448daff" className="card-img-top" alt="phenomeman" />
              <div className="card-body">
                <p className="card-text">Phenomeman</p>
              </div>
            </div>
          </div>
          
          <div className="col-md-4 mb-4">
            <div className="card" data-bs-toggle="tooltip" data-bs-placement="top" title="You got something on your..">
              <img src="https://preview.redd.it/but-if-invisigal-dose-have-a-romance-it-would-be-the-third-v0-l4obidgh4rcf1.png?width=436&format=png&auto=webp&s=ae2b4df0f1c3a15cad805f1c56775103810de556" className="card-img-top" alt="invisigal" />
              <div className="card-body">
                <p className="card-text">Invisigal</p>
              </div>
            </div>
          </div>
          
          <div className="col-md-4 mb-4">
            <div className="card" data-bs-toggle="tooltip" data-bs-placement="top" title="Hey, Nikki Mirage Im right here">
              <img src="https://mediaproxy.tvtropes.org/width/1200/https://static.tvtropes.org/pmwiki/pub/images/robertrobertson2.webp" className="card-img-top" alt="robert" />
              <div className="card-body">
                <p className="card-text">Mecha-man</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </main>
  );
}

export default Characters;