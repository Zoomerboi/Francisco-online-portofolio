import React, { useState } from 'react';

function Contact() {
  const [message, setMessage] = useState('');

  const handleSend = (e) => {
    const btn = e.target;
    btn.style.transform = "scale(0.90)";
    btn.style.transition = "transform 0.1s";
    setTimeout(() => {
        btn.style.transform = "scale(1)";
    }, 100);

    if (message.trim() === "") {
        alert("Please type a real message!");
        return; 
    }

    console.log(`User sent a message: ${message}`);
    alert(`Message Sent! You typed: ${message}`);

    setMessage(""); 
  };

  return (
    <main>
      <br />
      <p> <strong>Phone:</strong> 09956752909 </p>
      <p> <strong>Email:</strong> ethanedgarf@gmail.com </p>
      
      <div className="mb-3">
          <label htmlFor="messageInput" className="form-label" style={{ fontFamily: 'Verdana', fontSize: '110%' }}>
            Send me a message!
          </label>
          <textarea 
            className="form-control" 
            id="messageInput" 
            rows="3" 
            style={{ borderColor: 'rgb(112, 3, 3)', fontSize: '110%' }}
            // Bind value to state and update state on change
            value={message}
            onChange={(e) => setMessage(e.target.value)}
          ></textarea>
      </div>

      <button 
        id="sendBtn" 
        onClick={handleSend}
        style={{ 
          backgroundColor: 'rgb(112, 3, 3)', 
          color: 'yellow', 
          padding: '10px', 
          borderRadius: '20px', 
          opacity: '0.85',
          border: 'none' 
        }}
      >
        Send Message
      </button>

    </main>
  );
}

export default Contact;