import React, { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import HomeContent from './components/HomeContent';
import AboutMe from './components/AboutMe';
import Characters from './components/Characters';
import Contact from './components/Contact';

function App() {
  const location = useLocation();

  // useEffect Example 1: Scroll to top on route change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);

  return (
    <div className="content-container">
      <Header />
      
      <Routes>
        <Route path="/" element={<HomeContent />} />
        <Route path="/about" element={<AboutMe />} />
        <Route path="/characters" element={<Characters />} />
        <Route path="/contact" element={<Contact />} />
      </Routes>

      <Footer />
    </div>
  );
}

export default App;
