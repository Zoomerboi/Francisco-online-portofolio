class Task:
    def __init__(self, taskID, taskName, votes = 0):
        self.taskID = taskID                                # Sets value for the task ID
        self.taskName = taskName                            # Sets value for the task name
        self.votes = votes                                  # Sets value for the vote number

